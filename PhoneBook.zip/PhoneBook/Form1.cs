﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'appData.Phonebooks' table. You can move, or remove it, as needed.
            this.phonebooksTableAdapter.Fill(this.appData.Phonebooks);
            Edit(false);

        }
        private void Edit(bool value)
        {
            textBoxFname.Enabled = value;
            textBoxLname.Enabled = value;
            textBoxPhone.Enabled = value;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Edit(true);
                appData.Phonebooks.AddPhonebooksRow(appData.Phonebooks.NewPhonebooksRow());
                phonebooksBindingSource.MoveLast();
                textBoxPhone.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                appData.Phonebooks.RejectChanges();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            Edit(true);
            textBoxPhone.Focus();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                Edit(false);
                phonebooksBindingSource.EndEdit();
                phonebooksTableAdapter.Update(appData.Phonebooks);
                dataGridView1.Refresh();
                textBoxPhone.Focus();
                MessageBox.Show("Your data has been succesfully saved.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                appData.Phonebooks.RejectChanges();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Edit(false);
            phonebooksBindingSource.ResetBindings(false);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure want to delete this record?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                phonebooksBindingSource.RemoveCurrent();
        }
        

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (!string.IsNullOrEmpty(textBoxSearch.Text))
                    phonebooksBindingSource.Filter = string.Format(" firstName LIKE '%{0}%'", textBoxFname.Text);
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Delete)
            {
                if (MessageBox.Show("Are you sure want to delete this record?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    phonebooksBindingSource.RemoveCurrent();
            }
        }
    }
}
