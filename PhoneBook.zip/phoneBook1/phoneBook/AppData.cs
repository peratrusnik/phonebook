﻿namespace phoneBook
{
}

namespace phoneBook
{


    public partial class AppData
    {
    }
}
namespace phoneBook {
    
    
    public partial class AppData {
    }
}
